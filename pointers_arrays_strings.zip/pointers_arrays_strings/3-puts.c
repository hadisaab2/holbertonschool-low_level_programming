#include<stdio.h>
#include"main.h"
/**
* _puts - prints to stdout
* @str: string
*
*/

void _puts(char *str)
{
	printf("%s\n", str);
}
