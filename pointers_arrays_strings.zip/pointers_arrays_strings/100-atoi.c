#include<stdio.h>
#include"main.h"
/**
*_atoi - function
*@s: variable
*Return: int
*/
int _atoi(char *s)
{
	return (0);
}
