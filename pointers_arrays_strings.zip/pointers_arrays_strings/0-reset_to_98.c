#include<stdio.h>
#include"main.h"
/**
*reset_to_98 - function
*@n: variable
*/

void reset_to_98(int *n)
{
	*n = 98;
}
